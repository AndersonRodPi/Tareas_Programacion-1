#include "Secciones.h"

Secciones::Secciones()
{
    //ctor
}

Secciones::~Secciones()
{
    //dtor
}
