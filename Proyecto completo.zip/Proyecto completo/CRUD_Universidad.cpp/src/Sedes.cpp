#include "Sedes.h"

Sedes::Sedes()
{
    //ctor
}

Sedes::~Sedes()
{
    //dtor
}
