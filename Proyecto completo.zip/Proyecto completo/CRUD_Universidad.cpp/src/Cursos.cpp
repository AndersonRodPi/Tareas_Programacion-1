#include "Cursos.h"

Cursos::Cursos()
{
    //ctor
}

Cursos::~Cursos()
{
    //dtor
}
