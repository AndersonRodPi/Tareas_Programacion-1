#include "Horarios.h"

Horarios::Horarios()
{
    //ctor
}

Horarios::~Horarios()
{
    //dtor
}
