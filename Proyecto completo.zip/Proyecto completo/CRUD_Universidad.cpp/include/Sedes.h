#ifndef SEDES_H
#define SEDES_H


class Sedes
{
    public:
        Sedes();
        virtual ~Sedes();

    protected:

    private:
};

#endif // SEDES_H
