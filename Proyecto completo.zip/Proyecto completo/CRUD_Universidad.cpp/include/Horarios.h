#ifndef HORARIOS_H
#define HORARIOS_H


class Horarios
{
    public:
        Horarios();
        virtual ~Horarios();

    protected:

    private:
};

#endif // HORARIOS_H
