#ifndef SECCIONES_H
#define SECCIONES_H


class Secciones
{
    public:
        Secciones();
        virtual ~Secciones();

    protected:

    private:
};

#endif // SECCIONES_H
