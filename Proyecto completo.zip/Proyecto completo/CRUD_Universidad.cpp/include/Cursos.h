#ifndef CURSOS_H
#define CURSOS_H


class Cursos
{
    public:
        Cursos();
        virtual ~Cursos();

    protected:

    private:
};

#endif // CURSOS_H
